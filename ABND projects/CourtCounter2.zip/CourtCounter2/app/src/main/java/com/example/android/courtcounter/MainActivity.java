package com.example.android.courtcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int addScoreA = 0;
    int addScoreB = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }
    public void displayForTeamB(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }
        public void addSixPointsTeamA(View view) {
        addScoreA= addScoreA + 6;
        displayForTeamA(addScoreA);
    }
    public void addThreePointsTeamA(View view) {
        addScoreA= addScoreA + 3;
        displayForTeamA(addScoreA);
    }

    public void addTwoPointsTeamA(View view) {
        addScoreA= addScoreA + 2;
        displayForTeamA(addScoreA);
    }
    public void freeThrowTeamA(View view) {
        addScoreA= addScoreA + 1;
        displayForTeamA(addScoreA);
    }
public void addSixPointsTeamB(View view) {
        addScoreB= addScoreB + 6;
        displayForTeamB(addScoreB);
        }
    public void addThreePointsTeamB(View view) {
        addScoreB= addScoreB+ 3;
        displayForTeamB(addScoreB);
    }

    public void addTwoPointsTeamB(View view) {
        addScoreB= addScoreB + 2;
        displayForTeamB(addScoreB);
    }
    public void freeThrowTeamB(View view) {
        addScoreB= addScoreB + 1;
        displayForTeamB(addScoreB);
    }

    public void resetScores(View view){
        addScoreB = 0;
        addScoreA = 0;
        displayForTeamA(addScoreA);
        displayForTeamB(addScoreB);
    }

}
